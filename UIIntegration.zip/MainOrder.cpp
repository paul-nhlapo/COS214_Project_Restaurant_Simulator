#include "MainOrder.h"

MainOrder::MainOrder(BasicOrder* bo) : basicOrder(bo){
    this->oD = false;
}

std::string MainOrder::print(){
    std::string s = "Dish: " + basicOrder->dish + "\nMade by: " + basicOrder->type + " type\nBy: " + basicOrder->strategy + 
                    " strategy\nCost: R" + std::to_string(basicOrder->cost) + "\nTime to prepare: " + std::to_string(basicOrder->timeToPrep);
    return s;
}


double MainOrder::getCost(){
    return basicOrder->cost;
}

double MainOrder::getTimeToPrep(){
    return basicOrder->timeToPrep;
}

std::string MainOrder::getDish(){
    return basicOrder->dish;
}

std::string MainOrder::getStrategy(){
    return basicOrder->strategy;
}

std::string MainOrder::getType(){
    return basicOrder->type;
}


void MainOrder::setCost(double c){
    basicOrder->cost = c;
}

void MainOrder::setTimeToPrep(double t){
    basicOrder->timeToPrep = t;
}

void MainOrder::setDish(std::string d){
    basicOrder->dish = d;
}

void MainOrder::setStrategy(std::string s){
    basicOrder->strategy = s;
}

void MainOrder::setType(std::string c){
    basicOrder->type = c;
}
