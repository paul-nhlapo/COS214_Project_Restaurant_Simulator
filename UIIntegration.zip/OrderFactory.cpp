#include "OrderFactory.h"
#include "Order.h"
#include "MainOrder.h"
#include "BasicOrder.h"
#include "MainOrder.h"
#include "ProteinDecorator.h"
#include "SauceDecorator.h"
#include "SideDecorator.h"
#include "StarterDecorator.h"
#include "VegDecorator.h"
#include "DessertDecorator.h"
#include <string>
#include <vector>
#include <iostream>
#include "Table.h"
#include "OrderDetail.h"
using namespace std;

// OrderFactory::

OrderFactory::OrderFactory() : Factory()
{
}

OrderFactory::~OrderFactory()
{
}

vector<Order *> OrderFactory::getOrder(Table *t)
{
    vector<Order *> res;
    MainOrder *pushToRes = nullptr;
    char continueOrdering;

    BasicOrder *sideBO = nullptr;
    MainOrder *sideMO = nullptr;
    BasicOrder *vegBO = nullptr;
    MainOrder *vegMO = nullptr;
    BasicOrder *sBO = nullptr;
    // MainOrder *sideMO = nullptr;
    MainOrder *sMO = nullptr;
    do
    {
        int r1 = 0;
        int r2 = 0;
        int r3 = 0;
        int r4 = 0;
        int r5 = 0;
        int r6 = 0;
        string type = "";
        string dish = "";
        string strategy = "";
        string sauce = "";
        string side = "";
        string veg = "";
        cout << "Menu: " << endl;
        cout << "   1. Starter" << endl;
        cout << "   2. Main" << endl;
        cout << "   3. Dessert" << endl;
        cin >> r1;

        cout << "Starter: " << endl;
        switch (r1)
        {
        case 1:
            type = "Starter";
            cout << "   1. Bread Roll" << endl;
            cout << "   2. Soup" << endl;
            cin >> r2;

            switch (r2)
            {
            case 1:
                dish = "Bread Roll";
                break;
            case 2:
                dish = "Soup";
                break;
            default:
                dish = "Bread Roll";
                break;
            }

            cout << "Preference: " << endl;
            cout << "   1. Baked" << endl;
            cout << "   2. Simmer" << endl;

            cin >> r3;
            switch (r3)
            {
            case 1:
                strategy = "Baked";
                break;
            case 2:
                strategy = "Simmer";
                break;

            default:
                strategy = "Baked";
                break;
            }

            pushToRes = new StarterDecorator(new BasicOrder(dish, strategy, type));

            cout << "Sauce: " << endl;
            cout << "   1. Garlic" << endl;
            cout << "   2. Lemon" << endl;
            cout << "   3. Red Wine" << endl;

            cin >> r4;

            switch (r4)
            {
            case 1:
                sauce = "Garlic";
                break;
            case 2:
                sauce = "Lemon";
                break;
            case 3:
                sauce = "Red Wine";
                break;
            default:
                sauce = "Garlic";
                break;
            }
            sBO = new BasicOrder(sauce, "", "");
            pushToRes->next = new SauceDecorator(sBO);
            break;
        case 2:
            type = "Main";
            cout << "Protein: " << endl;
            cout << "   1. Steak" << endl;
            cout << "   2. Fish" << endl;
            cout << "   3. Chicken" << endl;
            cout << "   4. Vegan" << endl;

            // int r2;
            cin >> r2;

            switch (r2)
            {
            case 1:
                dish = "Steak";
                break;
            case 2:
                dish = "Fish";
                break;
            case 3:
                dish = "Chicken";
                break;
            case 4:
                dish = "Vegan";
                break;
            default:
                dish = "Vegan";
                break;
            }

            cout << "Preference: " << endl;
            cout << "   1. Fry" << endl;
            cout << "   2. Simmer" << endl;
            cout << "   3. Grill" << endl;
            cout << "   4. Boil" << endl;

            // int r3;
            cin >> r3;
            switch (r3)
            {
            case 1:
                strategy = "Fry";
                break;
            case 2:
                strategy = "Simmer";
                break;
            case 3:
                strategy = "Grill";
                break;
            case 4:
                strategy = "Boil";
                break;

            default:
                strategy = "Grill";
                break;
            }

            pushToRes = new ProteinDecorator(new BasicOrder(dish, strategy, type));

            cout << "Sauce: " << endl;
            cout << "   1. Garlic" << endl;
            cout << "   2. Lemon" << endl;
            cout << "   3. Red Wine" << endl;

            // int r4;
            cin >> r4;

            switch (r4)
            {
            case 1:
                sauce = "Garlic";
                break;
            case 2:
                sauce = "Lemon";
                break;
            case 3:
                sauce = "Red Wine";
                break;
            default:
                sauce = "Garlic";
                break;
            }

            cout << "Side: " << endl;
            cout << "   1. Chips" << endl;
            cout << "   2. Rice" << endl;
            cout << "   3. Salad" << endl;

            cin >> r5;

            switch (r5)
            {
            case 1:
                side = "Chips";
                break;
            case 2:
                side = "Rice";
                break;
            case 3:
                side = "Salad";
                break;
            default:
                side = "Chips";
                break;
            }

            cout << "Vegetables: " << endl;
            cout << "   1. Middle East" << endl;
            cout << "   2. Mediterranean" << endl;
            cout << "   3. South African" << endl;

            cin >> r6;

            switch (r6)
            {
            case 1:
                veg = "Middle East";
                break;
            case 2:
                veg = "Mediterranean";
                break;
            case 3:
                veg = "South African";
                break;
            default:
                veg = "South African";
                break;
            }
            vegBO = new BasicOrder(veg, "", "");
            vegMO = new VegDecorator(vegBO);

            sideBO = new BasicOrder(side, "", "");
            sideMO = new SideDecorator(sideBO);
            sideMO->next = vegMO;

            sBO = new BasicOrder(sauce, "", "");
            sMO = new SauceDecorator(sBO);
            sMO->next = sideMO;
            pushToRes->next = sMO;
            break;
        case 3:
            type = "Dessert";
            cout << "Preference: " << endl;
            cout << "   1. Hot" << endl;
            cout << "   2. Cold" << endl;

            // int r2;
            cin >> r2;
            switch (r2)
            {
            case 1:
                strategy = "HotDessert";
                cout << "Dish: " << endl;
                cout << "   1. Cake" << endl;
                cout << "   2. Malva Pudding" << endl;

                int r3;
                cin >> r3;

                switch (r3)
                {
                case 1:
                    dish = "Cake";
                    break;
                case 2:
                    dish = "Malva Pudding";
                    break;
                default:
                    dish = "Cake";
                    break;
                }
                break;
            case 2:
                strategy = "ColdDessert";
                //break;
                cout << "Dish: " << endl;
                cout << "   1. Ice Cream" << endl;
                cout << "   2. Chocolate Mousse" << endl;

                // int r3;
                cin >> r3;

                switch (r3)
                {
                case 1:
                    dish = "Ice Cream";
                    break;
                case 2:
                    dish = "Chocolate Mousse";
                    break;
                default:
                    dish = "Ice Cream";
                    break;
                }
                break;
            default:
                strategy = "Hot";
                dish = "Cake";
                break;
            }

            cout << "Side: " << endl;
            cout << "   1. Coffee" << endl;
            cout << "   2. Milkshake" << endl;

            // int r4;
            cin >> r4;

            switch (r4)
            {
            case 1:
                side = "Coffee";
                break;
            case 2:
                side = "Milkshake";
                break;
            default:
                side = "Coffee";
                break;
            }

            sideBO = new BasicOrder(dish, "", "");
            sideMO = new SideDecorator(sideBO);
            pushToRes = new DessertDecorator(new BasicOrder(dish, strategy, type));
            pushToRes->next = sideMO;
            break;
        default:
            cout << "Invalid choice" << endl;
            return res;
        }

        res.push_back(pushToRes);
        cout << "Do you want to order more? (Y/N): ";
        cin >> continueOrdering;
    } while (continueOrdering == 'Y' || continueOrdering == 'y');
    OrderDetail *orderDetail = new OrderDetail(t->tableID);
    res.insert(res.begin(), orderDetail);
    return res;
}

void OrderFactory::createProduct()
{
    return;
}
