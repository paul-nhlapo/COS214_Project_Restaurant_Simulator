#pragma once
#include "Staff.h"
#include "Table.h"
#include <vector>
#include <iostream>
// class Table;
class Waiter : public Staff
{
private:
    /* data */
public:
    vector<Table *> tables;
    //vector<string> orders;
    int income;
    Waiter(/* args */);
    ~Waiter();
    void process(Table *t);
    void printOrders();
};
