#ifndef ORDER_H
#define ORDER_H

#include <iostream>
#include <string>

class Order
{

public:
    virtual std::string print() = 0;

    virtual double getCost() = 0;
    virtual double getTimeToPrep() = 0;
    virtual std::string getDish() = 0;
    virtual std::string getStrategy() = 0;
    virtual std::string getType() = 0;

    virtual void setCost(double) = 0;
    virtual void setTimeToPrep(double) = 0;
    virtual void setDish(std::string) = 0;
    virtual void setStrategy(std::string) = 0;
    virtual void setType(std::string) = 0;

    double cost;
    double timeToPrep;
    std::string dish;
    std::string strategy;
    std::string type;
    bool oD;
    int tableID;

    /*
        Menu
            main - type
                protein - type
                    fish - dish
                    steak
                    chicken
                    pork
                side
                    chips
                    rice
                    salad

                sauce
                    mushroom
                    red wine
                    white wine
                    garlic butter
                veg
                    veg combo 1
                    veg combo 2
            starter - type
                soup - dish
                bread rolls - dish
            dessert - type
                ice cream
                choc cake
            drink - type
                water
                cooldrink


    strat : fried salad bake boil grill sushi simmer colddesset hotdessert

    - add costs , base
    - time to prep , base
    - printDetails , base (altered)

    - type (main,start,etc) , dec
    - prep strat , dec
    - type needed , dec

    orderdetail has default implementations of each menu item, if the person
        doesnt specify what method they want

    use the decorator to specify cooking strategies

    ---------------
    orderdetail specifies starter dessert and drink w/ default for all
    addOn turns into main
        main can then have each protien side and sauce as concDec

    */
};

#endif