#ifndef MAINORDER_H
#define MAINORDER_H

#include <iostream>

#include "Order.h"
#include "BasicOrder.h"

class MainOrder : public Order
{

public:
    MainOrder *next;

    MainOrder(BasicOrder *bo);

    virtual std::string print();

    virtual double getCost();
    virtual double getTimeToPrep();
    virtual std::string getDish();
    virtual std::string getStrategy();
    virtual std::string getType();

    virtual void setCost(double);
    virtual void setTimeToPrep(double);
    virtual void setDish(std::string);
    virtual void setStrategy(std::string);
    virtual void setType(std::string);

protected:
    BasicOrder *basicOrder;
};

#endif