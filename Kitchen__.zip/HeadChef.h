/*
    Head Chef Definition File
    - Inherits from Chef class
*/
#ifndef HEADCHEF_H
#define HEADCHEF_H

#include <queue>
#include "Chef.h"
class Meal;

class HeadChef : public Chef
{
    public:
        HeadChef(std::string name, Kitchen* kitchen);

        std::string getChefType();
        void receiveMeal(Meal* meal);                          //Set STATE to FREE to indicate they are able to receive a new meal object
        void receiveOrder() {};
        void addOrderToQueue(Order* order);                     //Head Chef pushes new orders to queues
        void sendMeal();                                        //Send Meal to Waiter
        void sendOrder() {};

        //void prepareMeal(std::string mealType);                 //CoR HANDLE method
        void prepareMeal(Order* order);
        void setNextChef(Chef* nextChef);                       //CoR setNext method

        void receiveNotification(Chef* senderChef);             //Sends a new order when notified that a chef is FREE

        Order* popStarterQueue();
        Order* popMainQueue();
        Order* popDessertQueue();

    private:
        //Queues to hold different Orders
        std::queue<Order*> starterQueue;                      
        std::queue<Order*> mainQueue;
        std::queue<Order*> dessertQueue;

        std::vector<Meal*> starterMeals;
        std::vector<Meal*> mainMeals;
        std::vector<Meal*> dessertMeals;

};
#endif