#ifndef MEALPRODUCT_H
#define MEALPRODUCT_H

#include <iostream>

class Meal
{
    public:
        Meal();
        virtual ~Meal() {};
        
        virtual std::string getMainElement();
        virtual std::string getCookingStrategy();
        virtual std::string getSide();
        virtual std::string getSauce();
        virtual std::string printMeal();
        virtual int getTableNumber();
        virtual std::string getMealType();

        virtual void setMainElement(std::string mainElement);
        virtual void setCookingStrategy(std::string);
        virtual void setSide(std::string);
        virtual void setSauce(std::string);
        virtual void setTableNumber(int);
        virtual void setMealType(std::string);

    protected:
        std::string mainElement;
        std::string side;
        std::string sauce;
        std::string cookingStrategy;
        int tableNumber;
        std::string mealType;
};
#endif