#ifndef MAINORDER_CPP
#define MAINORDER_CPP

#include "MainOrder.h"

MainOrder::MainOrder(std::string mainElement, std::string cookingMethod, std::string side, std::string sauce, int tableNumber)
{
    this->mainElement = mainElement;
    this->cookingMethod = cookingMethod;
    this->side = side;
    this->sauce = sauce;
    this->tableNumber = tableNumber;

    this->orderType = "Main";
}


std::string MainOrder::getOrderType()
{
    return this->orderType;
}

#endif