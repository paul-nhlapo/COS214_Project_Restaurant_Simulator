#ifndef STARTERORDER_CPP
#define STARTERORDER_CPP

#include "StarterOrder.h"

StarterOrder::StarterOrder(std::string mainElement, std::string cookingMethod, std::string side, std::string sauce, int tableNumber)
{
    this->mainElement = mainElement;
    this->cookingMethod = cookingMethod;
    this->side = side;
    this->sauce = sauce;
    this->tableNumber = tableNumber;

    this->orderType = "Starter";
}


std::string StarterOrder::getOrderType()
{
    return this->orderType;
}

#endif