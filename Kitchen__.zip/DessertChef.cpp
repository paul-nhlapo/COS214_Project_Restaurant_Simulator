/*
    Dessert Chef Implementation file
*/
#ifndef DESSERTCHEF_CPP
#define DESSERTCHEF_CPP

#include "DessertChef.h"
#include "MealProduct.h"
#include "DessertMealBuilder.h"
#include "CookingStrategy.h"
#include "HeadChef.h"

DessertChef::DessertChef(std::string name, Kitchen* kitchen) : Chef(name, kitchen)
{
    this->chefType = "Dessert Course Chef";
}

void DessertChef::receiveOrder()
{
    this->changeChefState();
}

void DessertChef::sendMeal(Meal* meal)
{
    if(headChef)
        headChef->receiveMeal(meal); 
}

std::string DessertChef::getChefType()
{
    return this->chefType;
}

void DessertChef::setHeadChef(Chef* headChef)
{
    this->headChef = headChef;
}

/*
void DessertChef::prepareMeal(std::string mealType)
{
    if(mealType == "Dessert")
    {
        std::cout << "Dessert Chef is preparing this meal";
    }

    else
    {
        std::cout << this->getChefType() << " passing meal on" << std::endl;
        nextChef->prepareMeal(mealType);
    }
}
*/

void DessertChef::prepareMeal(Order* order)
{
    
    if(order->getOrderType() == "Dessert")
    {
        this->changeChefState();
        
        std::cout << this->getChefType() <<" is preparing this meal" << std::endl << std::endl;
        
        //Strategies
        if(order->getCookingMethod() == "Cold Dessert")
            this->cookingStrategy = new ColdDessert();
        else if(order->getCookingMethod() == "Hot Dessert")
            this->cookingStrategy = new HotDessert();

        //Builder
        DessertMealBuilder* mealBuilder = new DessertMealBuilder();
        mealBuilder->setMainElement(order->getMainElement());

        mealBuilder->setMainElementPrepStrategy(cookingStrategy->cookMeal(order->getCookingMethod()));
        
        mealBuilder->setSideElement(order->getSide());
        mealBuilder->setSauceElement(order->getSauce());

        Meal* meal = mealBuilder->getMeal();

        delete this->cookingStrategy;
        this->cookingStrategy = NULL;

        sendMeal(meal);
    }

    else
    {
        std::cout << this->getChefType() << " passing this order on" << std::endl;
        nextChef->prepareMeal(order);
    }
}

void DessertChef::setNextChef(Chef* nextChef)
{
    this->nextChef = nextChef;
}

#endif