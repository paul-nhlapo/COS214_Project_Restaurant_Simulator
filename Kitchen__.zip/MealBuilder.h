#ifndef MEALBUILDER_H
#define MEALBUILDER_H

#include <iostream>

#include "MealProduct.h"

class MealBuilder
{
    public:
        MealBuilder() {};
        virtual ~MealBuilder() {};

        void virtual setMainElement(std::string mainElement) = 0;
        void virtual setMainElementPrepStrategy(std::string mainElementPrepStrategy) = 0;

        // void virtual setSideChoice(char sideChoice) = 0;
        void virtual setSideElement(std::string side) = 0;
        void virtual setSidePrepStrategy(std::string sidePrepStrategy) = 0;

        // void virtual setSauceChoice(char sauceChoice) = 0;
        void virtual setSauceElement(std::string sauce) = 0;

        virtual Meal* getMeal() = 0;

    protected:
        Meal* meal;
};
#endif