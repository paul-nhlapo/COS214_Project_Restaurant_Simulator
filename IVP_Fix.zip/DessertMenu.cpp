#ifndef DESSERTMENU_CPP
#define DESSERTMENU_CPP

#include "DessertMenu.h"

DessertMenu::DessertMenu()
{
    // mainElementItems.push_back({"Vanilla Ice Cream", {""}});                                      //Cold Dessert
    // mainElementItems.push_back({"Malva Pudding", {""}});                                          //Warm Dessert
    // mainElementItems.push_back({"Chocolate Lava Cake", {""}});                                    //Warm Dessert
    // mainElementItems.push_back({"Apple Crumble", {""}});                                          //Warm Dessert
    // mainElementItems.push_back({"Lemon Cheesecake", {""}});                                       //Cold Dessert

    std::vector<ItemDetails> mainItems_ = 
    {
        {1, 75, "Vanilla Ice Cream", {""}},
        {2, 80, "Malva Pudding", {""}},
        {3, 50, "Chocolate Lava Cake", {""}},
        {4, 55, "Apple Crumble", {""}},
        {5, 55, "Lemon Cheesecake", {""}},
    };

    mainElementItems = mainItems_;

    // sidesItems.push_back({"Fresh Fruit", {""}});                                                      //No Cook
    // sidesItems.push_back({"Whipped Cream", {""}});                                                    //No Cook
    // sidesItems.push_back({"Chocolate Pieces", {""}});                                                 //No Cook

    std::vector<ItemDetails> sideItems_ = 
    {
        {1, 75, "Fresh Fruit", {""}},
        {2, 80, "Whipped Cream", {""}},
        {3, 50, "Butter Biscuits", {""}},
    };

    sidesItems = sideItems_;

    // sauceItems.push_back({"Caramel Sauce"});
    // sauceItems.push_back({"Chocolate Sauce"});
    // sauceItems.push_back({"Raspberry Sauce"});

    std::vector<ItemDetails> sauceItems_ = 
    {
        {1, 15, "Caramel Sauce", {""}},
        {2, 14, "Chocolate Sauce", {""}},
        {3, 25, "Raspberry Sauce", {""}},
    };

    sauceItems = sauceItems_;

    this->menuType = "Dessert";
}

std::string DessertMenu::getMenuType()
{
    return this->menuType;
}

#endif