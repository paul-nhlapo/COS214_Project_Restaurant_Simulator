#ifndef MEAL_CPP
#define MEAL_CPP

#include "MealProduct.h"

Meal::Meal()
{

}

std::string Meal::getMainElement()
{
    return this->mainElement;
}

std::string Meal::getSide()
{
    return this->side;
}

std::string Meal::getSauce()
{
    return this->sauce;
}

std::string Meal::getCookingStrategy()
{
    return this->cookingStrategy;
}

void Meal::setMainElement(std::string mainElement)
{
    this->mainElement = mainElement;
}

void Meal::setCookingStrategy(std::string prepStrategy)
{
    this->cookingStrategy = prepStrategy;
}

void Meal::setSide(std::string side)
{
    this->side = side;
}

void Meal::setSauce(std::string sauce)
{
    this->sauce = sauce;
}

std::string Meal::printMeal()
{
    std::string meal = "";

    meal += this->getCookingStrategy() + " " + this->getMainElement();

    if(this->getSide() != "")
    {
        meal += "with " + this->getSide();
    }

    if(this->getSauce() != " ")
    {
        meal += "and a " + this->getSauce();
    }

    return meal;
}

#endif