#ifndef ORDER_H
#define ORDER_H

#include <iostream>

class Order_
{
    public:
        std::string menuChoice;
        int mainElement;
        int mainPrepStrategy;
        int sidePrepStrategy;
        char sidesChoice;
        int sidesElement;
        char sauceChoice;
        int sauceElement;

    // Additional attributes and methods can be added as needed

    Order_() 
    {
        menuChoice = "";
        mainElement = -1;
        mainPrepStrategy = -1;
        sidePrepStrategy = -1;
        sidesChoice = 'N';
        sidesElement = -1;
        sauceChoice = 'N';
        sauceElement = -1;
    }
};

#endif
