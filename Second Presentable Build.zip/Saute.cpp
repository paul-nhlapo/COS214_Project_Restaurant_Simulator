#include "CookingStrategy.h"

Saute::Saute() {}

Saute::~Saute() {}

std::string Saute::cookMeal(std::string prepMethod)
{
    return "Sautéd";
}
