#include "CookingStrategy.h"

ColdDessert::ColdDessert() {}

ColdDessert::~ColdDessert() {}

std::string ColdDessert::cookMeal(std::string prepMethod)
{
    return "Chilled ";
}