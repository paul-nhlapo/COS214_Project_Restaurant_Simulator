#include "Staff.h"
#include <string>
#include <vector>
using namespace std;

Staff::Staff(/* args */)
{
}

Staff::~Staff()
{
}
