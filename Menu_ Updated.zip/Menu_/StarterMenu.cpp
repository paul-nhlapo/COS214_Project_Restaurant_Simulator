#ifndef STARTERMENU_CPP
#define STARTERMENU_CPP

#include "StarterMenu.h"

StarterMenu::StarterMenu()
{
    // mainElementItems.push_back({"Chicken Salad", {"Grilled", "Fried", "Baked"}});
    // mainElementItems.push_back({"Sushi", {""}});                                                   //Sushi
    // mainElementItems.push_back({"Pumpkin Soup", {""}});                                            //Simmered
    // mainElementItems.push_back({"Butternut Soup", {""}});                                          //Simmered
    // mainElementItems.push_back({"Tomato Soup", {""}});                                             //Simmered
    // mainElementItems.push_back({"Calamari", {"Fried", "Grilled"}});           
    // mainElementItems.push_back({"Caeasar Salad", {""}});                                           //Salad
    // mainElementItems.push_back({"Samoosas", {""}});                                                //Fried
    // mainElementItems.push_back({"Tapas", {"Grilled", "Fried", "Baked"}});
    // mainElementItems.push_back({"Empanadas", {""}});                                               //Baked

    std::vector<ItemDetails> mainItems_ = 
    {
        {1, 75, "Chicken Salad", {"Grilled", "Fried", "Baked"}},
        {2, 80, "Sushi", {""}},
        {3, 50, "Pumpkin Soup", {""}},
        {4, 55, "Butternut Soup", {""}},
        {5, 55, "Tomato Soup", {""}},
        {6, 70, "Calamari", {"Fried", "Grilled"}},
        {7, 45, "Caeasar Salad", {""}},
        {8, 25, "Samoosas", {""}},
        {9, 85, "Tapas", {"Grilled", "Fried", "Baked"}},
        {10, 70, "Empanadas", {""}}
    };

    mainElementItems = mainItems_;

    std::vector<ItemDetails> sideItems_ = 
    {
        {1, 75, "Bread Rolls", {""}},
        {2, 80, "Bread Sticks", {""}},
        {3, 50, "Mozzarella Sticks", {""}},
        {4, 55, "Nachos", {""}},
        {5, 55, "Buffalo Wings", {""}},
    };

    sidesItems = sideItems_;

    // sidesItems.push_back({"Bread Rolls", {""}});                                                       //Baked
    // sidesItems.push_back({"Bread Sticks", {""}});                                                      //Baked
    // sidesItems.push_back({"Mozzarella Sticks", {""}});                                                 //No Cook
    // sidesItems.push_back({"Nachos", {}});                                                              //Baked          
    // sidesItems.push_back({"Chicken Wings", {}});                                                       //Fried

    // sauceItems.push_back({"Soy Sauce"});
    // sauceItems.push_back({"Salad Dressing"});
    // sauceItems.push_back({"Guacamole"});
    // sauceItems.push_back({"Mushroom Sauce"});
    // sauceItems.push_back({"Hot Sauce"});

    std::vector<ItemDetails> sauceItems_ = 
    {
        {1, 15, "Soy Sauce", {""}},
        {2, 14, "Salad Dressing", {""}},
        {3, 25, "Guacamole", {""}},
        {4, 18, "Mushroom Sauce", {""}},
        {5, 9, "Hot Sauce", {""}},
    };

    sauceItems = sauceItems_;

    this->menuType = "Starter";
}

std::string StarterMenu::getMenuType()
{
    return this->menuType;
}

#endif