#include "Waiter.h"
#include <string>
using namespace std;

Waiter::Waiter()
{
    this->income = 0;

    starterMenu = new StarterMenu();
    mainMenu = new MainMenu();
    dessertMenu = new DessertMenu();
}

Waiter::~Waiter()
{
    // delete starterMenu;
    // delete mainMenu;
    // delete dessertMenu;
}

void Waiter::process(Table *t)
{
}
// {
//     //orders.push_back(t->tempOrder);
//     //printOrders();
//     //string done = t->tempOrder;
//     //orders.pop_back();
//     cout << "Complete order? " << endl;
//     char y = ' ';
//     cin >> y;
//     //t->completedOrders.push_back(done);
//     Customer *firstCustomer = t->customers.front();
//     if (firstCustomer == nullptr)
//     {
//         return;
//     }
//     this->income = firstCustomer->tip();
//     cout << "Income: R" << this->income << endl;
// }

void Waiter::takeOrder()
{
    std::cout << "Would you like to order: " << std::endl;
    std::cout << "1. Starters" << std::endl;
    std::cout << "2. Main" << std::endl;
    std::cout << "3. Dessert" << std::endl;

    int menuChoice;
    cin >> menuChoice;

    while (menuChoice != 1 && menuChoice != 2 && menuChoice != 3)
    {
        std::cout << "Please enter a valid number" << std::endl;
        cin >> menuChoice;
        std::cout << std::endl
                  << std::endl;
    }

    if (menuChoice == 1)
    {
        OrderBuilder *starterBuilder = new StarterOrderBuilder();

        std::cout << "What would you like for your starter? :" << std::endl
                  << std::endl;
        starterMenu->printMainElementList();

        int starterMainElement;
        cin >> starterMainElement;
        std::cout << std::endl;

        starterBuilder->setMainElement(starterMainElement);

        if (starterMainElement == 1 || starterMainElement == 6 || starterMainElement == 9)
        {
            starterMenu->printMainElementStrategyList(starterMainElement);
            int mainPrepStrategy;
            cin >> mainPrepStrategy;
            starterBuilder->setMainElementPrepStrategy(mainPrepStrategy);
        }

        std::cout << "Would you like any sides with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sidesChoice = ' ';
        cin >> sidesChoice;

        starterBuilder->setSideChoice(sidesChoice);

        if (sidesChoice == 'Y' || sidesChoice == 'y')
        {
            std::cout << "What side would you like? :" << std::endl
                      << std::endl;
            std::cout << "error 0" << std::endl;
            starterMenu->printSideItemsList();
            std::cout << "error 1" << std::endl;
            int sidesElementChoice;
            std::cout << "error 2" << std::endl;
            cin >> sidesElementChoice;
            std::cout << "error 3" << std::endl;

            starterBuilder->setSideElement(sidesElementChoice);
            std::cout << "error 4" << std::endl;
        }

        std::cout << "Would you like a sauce with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sauceChoice = ' ';
        cin >> sauceChoice;

        starterBuilder->setSauceChoice(sauceChoice);

        if (sauceChoice == 'Y' || 'y')
        {
            std::cout << "What sauce would you like? :" << std::endl
                      << std::endl;
            starterMenu->printSauceItemsList();

            int sauceElementChoice;
            cin >> sauceElementChoice;

            starterBuilder->setSauceElement(sauceElementChoice);
        }

        this->addOrder(starterBuilder->getOrder());
        // delete starterBuilder;
    }

    else if (menuChoice == 2)
    {
        std::cout << "What would you like for your main? :" << std::endl
                  << std::endl;
        mainMenu->printMainElementList();

        int mainMainElement;
        cin >> mainMainElement;
        std::cout << std::endl;

        if (mainMainElement == 1 || mainMainElement == 4 || mainMainElement == 6 || mainMainElement == 8)
        {
            mainMenu->printMainElementStrategyList(mainMainElement);
            int mainPrepStrategy;
            cin >> mainPrepStrategy;
        }

        std::cout << "Would you like any sides with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sidesChoice = ' ';
        cin >> sidesChoice;
        if (sidesChoice == 'Y' || 'y')
        {
            std::cout << "What side would you like? :" << std::endl
                      << std::endl;
            mainMenu->printSideItemsList();

            int sidesElementChoice;
            cin >> sidesElementChoice;
        }

        std::cout << "Would you like a sauce with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sauceChoice = ' ';
        cin >> sauceChoice;
        if (sauceChoice == 'Y' || 'y')
        {
            std::cout << "What sauce would you like? :" << std::endl
                      << std::endl;
            mainMenu->printSauceItemsList();

            int sidesElementChoice;
            cin >> sidesElementChoice;
        }
    }

    else if (menuChoice == 3)
    {
        std::cout << "What would you like for your dessert? :" << std::endl
                  << std::endl;
        dessertMenu->printMainElementList();

        int dessertMainElement;
        cin >> dessertMainElement;
        std::cout << std::endl;

        std::cout << "Would you like any sides with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sidesChoice = ' ';
        cin >> sidesChoice;
        if (sidesChoice == 'Y' || 'y')
        {
            std::cout << "What side would you like? :" << std::endl
                      << std::endl;
            dessertMenu->printSideItemsList();

            int sidesElementChoice;
            cin >> sidesElementChoice;
        }

        std::cout << "Would you like a sauce with your meal? (Y/N)" << std::endl
                  << std::endl;
        char sauceChoice = ' ';
        cin >> sauceChoice;
        if (sauceChoice == 'Y' || 'y')
        {
            std::cout << "What sauce would you like? :" << std::endl
                      << std::endl;
            dessertMenu->printSauceItemsList();

            int sidesElementChoice;
            cin >> sidesElementChoice;
        }
    }
}

void Waiter::addOrder(Order_ *order)
{
    orders.push_back(order);
}

void Waiter::printOrders()
{
    cout << "Waiter's orders:" << endl;
    for (Order_ *order : orders)
    {
        cout << "Main Element: " << order->mainElement << " mainPrepStrategy:  " << order->mainPrepStrategy << " sauceChoice: " << order->sauceElement << " sidesChoice: " << order->sidesElement << endl;
    }
}