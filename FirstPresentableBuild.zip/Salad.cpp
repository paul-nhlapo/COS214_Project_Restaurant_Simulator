#include "CookingStrategy.h"

Salad::Salad() {}

Salad::~Salad() {}

std::string Salad::cookMeal(std::string prepMethod)
{
    return "Freshly made ";
}