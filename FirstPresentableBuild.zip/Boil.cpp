#include "CookingStrategy.h"

Boil::Boil() {}

Boil::~Boil() {}

std::string Boil::cookMeal(std::string prepMethod)
{
    return "Boil ";
}
