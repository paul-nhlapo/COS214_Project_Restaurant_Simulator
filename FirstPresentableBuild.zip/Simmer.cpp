#include "CookingStrategy.h"

Simmer::Simmer() {}

Simmer::~Simmer() {}

std::string Simmer::cookMeal(std::string prepMethod)
{
    return "Simmer ";
}
