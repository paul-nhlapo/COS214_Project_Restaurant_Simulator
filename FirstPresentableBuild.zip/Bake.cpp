#include "CookingStrategy.h"
Bake::Bake() {}

Bake::~Bake() {}

std::string Bake::cookMeal(std::string prepMethod)
{
    return "Baked ";
}