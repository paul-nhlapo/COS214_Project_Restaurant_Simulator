#include "CookingStrategy.h"

Sushi::Sushi() {}

Sushi::~Sushi() {}

std::string Sushi::cookMeal(std::string prepMethod)
{
    return "Fresh handmade ";
}
