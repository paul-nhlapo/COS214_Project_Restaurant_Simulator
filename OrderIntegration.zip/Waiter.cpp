#include "Waiter.h"
#include <string>
using namespace std;

Waiter::Waiter(/* args */)
{
    this->income = 0;
}

Waiter::~Waiter()
{
}

void Waiter::process(Table *t)
{
    //orders.push_back(t->tempOrder);
    //printOrders();
    //string done = t->tempOrder;
    //orders.pop_back();
    cout << "Complete order? " << endl;
    char y = ' ';
    cin >> y;
    //t->completedOrders.push_back(done);
    Customer *firstCustomer = t->customers.front();
    if (firstCustomer == nullptr)
    {
        return;
    }
    this->income = firstCustomer->tip();
    cout << "Income: R" << this->income << endl;
}

void Waiter::printOrders()
{
    cout << "Waiter's orders:" << endl;
    // for (const auto &order : orders)
    // {
    //     cout << order << endl;
    // }
}