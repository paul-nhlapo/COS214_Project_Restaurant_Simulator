#include "CookingStrategy.h"

Fry::Fry(){};

Fry::~Fry(){};

std::string Fry::cookMeal(std::string prepMethod)
{
    return "Fried ";
}
