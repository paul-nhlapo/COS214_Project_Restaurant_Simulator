#include "CookingStrategy.h"

Grill::Grill(){};

std::string Grill::cookMeal(std::string prepMethod)
{
    return "Grilled ";
}

Grill::~Grill(){};
