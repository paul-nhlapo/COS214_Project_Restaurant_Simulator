#include "CookingStrategy.h"

HotDessert::HotDessert() {}

HotDessert::~HotDessert() {}

std::string HotDessert::cookMeal(std::string prepMethod)
{
    return "Warm ";
}