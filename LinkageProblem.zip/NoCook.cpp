#include "CookingStrategy.h"

NoCook::NoCook() {}

NoCook::~NoCook() {}

std::string NoCook::cookMeal(std::string prepMethod)
{
    return "";
}
