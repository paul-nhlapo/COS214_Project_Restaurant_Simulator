/*
    Main Chef Implementation file
*/
#ifndef MAINCHEF_CPP
#define MAINCHEF_CPP

#include "MainChef.h"
#include "MealProduct.h"
#include "MainMealBuilder.h"
#include "CookingStrategy.h"
#include "HeadChef.h"

MainChef::MainChef(std::string name, Kitchen *kitchen) : Chef(name, kitchen)
{
    this->chefType = "Main Course Chef";
}

void MainChef::receiveOrder()
{
    this->changeChefState();
}

void MainChef::sendMeal(Meal *meal)
{
    if (headChef)
        headChef->receiveMeal(meal);
}

std::string MainChef::getChefType()
{
    return this->chefType;
}

void MainChef::setHeadChef(Chef *headChef)
{
    this->headChef = headChef;
}

/**
 * @brief Prepares a main meal order by selecting a cooking strategy based on the order's cooking method,
 *        building the meal using a MainMealBuilder, and sending the meal to be served.
 *
 * @param order Pointer to the order to be prepared.
 */
void MainChef::prepareMeal(Order *order)
{
    if (order == NULL)
    {
        std::cout << "Order is NULL. Cannot prepare meal." << std::endl;
        return;
    }

    if (order->getOrderType() == "Main")
    {
        this->changeChefState();

        std::cout << this->getChefType() << " is preparing this meal" << std::endl
                  << std::endl;

        // Strategies
        if (order->getCookingMethod() == "Grilled")
            this->cookingStrategy = new Grill();
        else if (order->getCookingMethod() == "Fried")
            this->cookingStrategy = new Fry();
        else if (order->getCookingMethod() == "Baked")
            this->cookingStrategy = new Bake();
        else if (order->getCookingMethod() == "Boiled")
            this->cookingStrategy = new Boil();
        else if (order->getCookingMethod() == "Sushi")
            this->cookingStrategy = new Sushi();
        else if (order->getCookingMethod() == "Saute")
            this->cookingStrategy = new Saute();
        else if (order->getCookingMethod() == "Simmered")
            this->cookingStrategy = new Simmer();
        else if (order->getCookingMethod() == "Salad")
            this->cookingStrategy = new Salad();
        else
        {
            std::cout << "Invalid cooking method. Cannot prepare meal." << std::endl;
            return;
        }
        // Builder
        MainMealBuilder *mealBuilder = new MainMealBuilder();

        mealBuilder->setMainElement(order->getMainElement());
        mealBuilder->setMainElementPrepStrategy(cookingStrategy->cookMeal(order->getCookingMethod()));

        mealBuilder->setSideElement(order->getSide());
        mealBuilder->setSauceElement(order->getSauce());

        Meal *meal = mealBuilder->getMeal();

        // delete this->cookingStrategy;
        // this->cookingStrategy = NULL;

        sendMeal(meal);
    }

    else if (nextChef != NULL)
    {
        std::cout << this->getChefType() << " passing this order on" << std::endl;
        nextChef->prepareMeal(order);
    }
    else
    {
        std::cout << "Next chef is NULL. Cannot pass on order." << std::endl;
    }
}

void MainChef::setNextChef(Chef *nextChef)
{
    this->nextChef = nextChef;
}

#endif