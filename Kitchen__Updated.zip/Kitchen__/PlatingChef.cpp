/*
    Starter Chef Implementation file
*/
#ifndef PLATINGCHEF_CPP
#define PLATINGCHEF_CPP

#include "StarterChef.h"
#include "MealProduct.h"
#include "StarterMealBuilder.h"
#include "CookingStrategy.h"

StarterChef::StarterChef(std::string name, Kitchen* kitchen) : Chef(name, kitchen)
{
    this->chefType = "Plating Chef";
}

void StarterChef::receiveOrder()
{

}

void StarterChef::sendOrder()
{

}

std::string StarterChef::getChefType()
{
    return this->chefType;
}

/*
void StarterChef::prepareMeal(std::string mealType)
{
    if(mealType == "Starter")
    {
        std::cout << this->getChefType() <<" is preparing this meal";
    }

    else
    {
        std::cout << this->getChefType() << " passing meal on" << std::endl;
        nextChef->prepareMeal(mealType);
    }
}
*/

void StarterChef::prepareMeal(Order* order)
{
    if(order->getOrderType() == "Starter")
    {
        std::cout << this->getChefType() <<" is preparing this meal" << std::endl << std::endl;
        
        //Strategies
        if(order->getCookingMethod() == "Grilled")
            this->cookingStrategy = new Grill();
        else if(order->getCookingMethod() == "Fried")
            this->cookingStrategy = new Fry();
        else if(order->getCookingMethod() == "Baked")
            this->cookingStrategy = new Bake();            
        else if(order->getCookingMethod() == "Boiled")
            this->cookingStrategy = new Boil();
        else if(order->getCookingMethod() == "Sushi")
            this->cookingStrategy = new Sushi();
        else if(order->getCookingMethod() == "Saute")
            this->cookingStrategy = new Saute();
        else if(order->getCookingMethod() == "Simmered")
            this->cookingStrategy = new Simmer();
        else if(order->getCookingMethod() == "Salad")
            this->cookingStrategy = new Salad();

        //Builder
        StarterMealBuilder mealBuilder;

        mealBuilder.setMainElement(order->getMainElement());
        mealBuilder.setMainElementPrepStrategy(cookingStrategy->cookMeal(order->getCookingMethod()));
        
        mealBuilder.setSideElement(order->getSide());
        mealBuilder.setSauceElement(order->getSauce());

        Meal* meal = mealBuilder.getMeal();

        delete this->cookingStrategy;
        this->cookingStrategy = NULL;
    }

    else
    {
        std::cout << this->getChefType() << " passing this order on" << std::endl;
        nextChef->prepareMeal(order);
    }
}

void StarterChef::setNextChef(Chef* nextChef)
{
    this->nextChef = nextChef;
}

#endif