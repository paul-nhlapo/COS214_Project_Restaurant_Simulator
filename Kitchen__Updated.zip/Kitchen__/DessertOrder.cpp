#ifndef DESSERTORDER_CPP
#define DESSERTORDER_CPP

#include "DessertOrder.h"

DessertOrder::DessertOrder(std::string mainElement, std::string cookingMethod, std::string side, std::string sauce, int tableNumber)
{
    this->mainElement = mainElement;
    this->cookingMethod = cookingMethod;
    this->side = side;
    this->sauce = sauce;
    this->tableNumber = tableNumber;

    this->orderType = "Dessert";
}


std::string DessertOrder::getOrderType()
{
    return this->orderType;
}

#endif