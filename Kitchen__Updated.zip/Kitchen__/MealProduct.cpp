#ifndef MEALPRODUCT_CPP
#define MEALPRODUCT_CPP

#include "MealProduct.h"

Meal::Meal()
{

}

std::string Meal::getMainElement()
{
    return this->mainElement;
}

std::string Meal::getSide()
{
    return this->side;
}

std::string Meal::getSauce()
{
    return this->sauce;
}

std::string Meal::getCookingStrategy()
{
    return this->cookingStrategy;
}

int Meal::getTableNumber()
{
    return this->tableNumber;
}

std::string Meal::getMealType()
{
    return this->mealType;
}

void Meal::setMainElement(std::string mainElement)
{
    this->mainElement = mainElement;
}

void Meal::setCookingStrategy(std::string prepStrategy)
{
    this->cookingStrategy = prepStrategy;
}

void Meal::setSide(std::string side)
{
    this->side = side;
}

void Meal::setSauce(std::string sauce)
{
    this->sauce = sauce;
}

void Meal::setTableNumber(int tableNumber)
{
    this->tableNumber = tableNumber;
}

void Meal::setMealType(std::string mealType)
{
    this->mealType = mealType;
}


std::string Meal::printMeal()
{
    std::string meal = "";

    meal += this->getCookingStrategy() + " " + this->getMainElement();

    if(this->getSide() != "")
    {
        meal += "with " + this->getSide();
    }

    if(this->getSauce() != " ")
    {
        meal += "and a " + this->getSauce();
    }

    return meal;
}

#endif