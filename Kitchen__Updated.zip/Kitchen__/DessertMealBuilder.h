#ifndef DESSERTMEALBUILDER_H
#define DESSERTMEALBUILDER_H

#include "MealBuilder.h"

class DessertMealBuilder : public MealBuilder
{
    public:
        DessertMealBuilder();
        // ~DessertMealBuilder();
        
        void setMainElement(std::string mainElement);
        void setMainElementPrepStrategy(std::string mainElementPrepStrategy);

        void setSideElement(std::string side);
        void setSidePrepStrategy(std::string sidePrepStrategy);

        void setSauceElement(std::string sauce);

        void setTableNumber(int tableNumber);

        Meal* getMeal();
};

#endif