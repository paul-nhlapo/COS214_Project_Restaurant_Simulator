#include "Waiter.h"
#include <iostream>

Waiter::Waiter()
{
    this->balance = 0.0;
}

void Waiter::process(Table *t)
{
}

void Waiter::visitTable(Table *table)
{
    std::cout << "taking order at table : " << table->tableID << "\n";
    this->orders = table->order;
}

void Waiter::visitAllTable(std::vector<Table *> table)
{
    std::cout << "floor waiter cant visit all tables, not a head waiter\n";
}

void Waiter::printOrders()
{
    cout << "Testing Waiter's Orders: " << endl
         << endl;
    for (Order *order : this->orders)
    {
        MainOrder *mainOrder = dynamic_cast<MainOrder *>(order);
        if (mainOrder != nullptr)
        {
            // This is a MainOrder object
            while (mainOrder != nullptr)
            {
                cout << "Type: " << mainOrder->getType() << ", Dish: " << mainOrder->getDish() << ", Strategy: " << mainOrder->getStrategy() << endl;
                mainOrder = mainOrder->next;
            }
        }
        else
        {
            // This is a regular Order object
            cout << "Table Number: " << order->tableID << endl;
        }
    }
}

void Waiter::receiveBill(Table *table)
{
    table->payTheBill(this);
}
