var searchData=
[
  ['name_0',['name',['../class_chef.html#ae05f33ffa7813875a22851cea1ee5e66',1,'Chef::name'],['../class_cocktail_order.html#a5fb72bf9061604fce52f60937e8bb8a2',1,'CocktailOrder::name']]],
  ['nextchef_1',['nextChef',['../class_chef.html#afc06a34f1b5626899012395ed0c8a7f8',1,'Chef']]],
  ['nextgroupid_2',['nextgroupid',['../classcustomer_factory.html#ad06da9e0b2f0f38d42fe9c31ff60b55f',1,'customerFactory::nextGroupID'],['../class_order_factory.html#a943912e80690a1e3e35a823d582acd73',1,'OrderFactory::nextGroupID']]],
  ['nextitem_3',['nextItem',['../class_add_on.html#a32744991b0d9e448fd286420b3c24314',1,'AddOn']]],
  ['nocook_4',['nocook',['../class_no_cook.html',1,'NoCook'],['../class_no_cook.html#a7373bbeb462fa34435440f56ae911b67',1,'NoCook::NoCook()']]],
  ['nocook_2ecpp_5',['NoCook.cpp',['../_no_cook_8cpp.html',1,'']]],
  ['notifymealready_6',['notifyMealReady',['../class_kitchen.html#a9d403f0fcc70a7fa441a608f04710163',1,'Kitchen']]],
  ['notifystatechange_7',['notifyStateChange',['../class_kitchen.html#a8e045743d419a42023b8820de9ef088f',1,'Kitchen']]],
  ['numcols_8',['numCols',['../class_floor.html#a580ca4bc9949485cbf9631c46548a4c9',1,'Floor']]],
  ['numrows_9',['numRows',['../class_floor.html#ae8601522b225ab8f239adeb34b210ca6',1,'Floor']]]
];
