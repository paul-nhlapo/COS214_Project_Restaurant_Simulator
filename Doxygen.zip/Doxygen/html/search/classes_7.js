var searchData=
[
  ['ice_0',['Ice',['../class_ice.html',1,'']]],
  ['individual_1',['Individual',['../class_individual.html',1,'']]],
  ['itemdetails_2',['ItemDetails',['../struct_menu_1_1_item_details.html',1,'Menu']]]
];
