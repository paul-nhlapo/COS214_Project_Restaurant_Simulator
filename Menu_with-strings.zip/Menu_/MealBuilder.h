#ifndef MEALBUILDER_H
#define MEALBUILDER_H

#include <iostream>

#include "MealProduct.h"

class MealBuilder
{
public:
    MealBuilder();

    void virtual setMainElement(int mainElement) = 0;
    void virtual setMainElementPrepStrategy(int mainElementPrepStrategy) = 0;

    void virtual setSideChoice(char sideChoice) = 0;
    void virtual setSideElement(int side) = 0;
    void virtual setSidePrepStrategy(int sidePrepStrategy) = 0;

    void virtual setSauceChoice(char sauceChoice) = 0;
    void virtual setSauceElement(int sauce) = 0;

    virtual Meal *getMeal() = 0;

protected:
    Meal *meal;
};
#endif