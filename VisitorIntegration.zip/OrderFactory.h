#pragma once
#include "Factory.h"
#include "Order.h"
#include "Individual.h"
#include <vector>
using namespace std;

class Table;
class OrderFactory : public Factory
{
private:
    int current;

public:
    char nextGroupID;
    OrderFactory();
    ~OrderFactory();
    vector<Order *> getOrder(Table *t);
    void createProduct();
};
