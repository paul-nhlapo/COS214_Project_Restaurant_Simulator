#ifndef COOKINGSTRATEGY_CPP
#define COOKINGSTRATEGY_CPP

#include "CookingStrategy.h"


#endif