#ifndef COOKINGSTRATEGY_CPP
#define COOKINGSTRATEGY_CPP

#include "CookingStrategy.h"

std::string Fry::cookMeal(std::string prepMethod)
{
    return "Fried ";
}

std::string Grill::cookMeal(std::string prepMethod)
{
    return "Grilled ";
}

std::string Bake::cookMeal(std::string prepMethod)
{
    return "Baked ";
}

std::string Boil::cookMeal(std::string prepMethod)
{
    return "Boil ";
}

std::string Sushi::cookMeal(std::string prepMethod)
{
    return "Fresh handmade ";
}

std::string Saute::cookMeal(std::string prepMethod)
{
    return "Sautéd ";
}

std::string Simmer::cookMeal(std::string prepMethod)
{
    return "Simmer ";
}

std::string NoCook::cookMeal(std::string prepMethod)
{
    return "";
}

std::string Salad::cookMeal(std::string prepMethod)
{
    return "Freshly made ";
}

std::string ColdDessert::cookMeal(std::string prepMethod)
{
    return "Chilled ";
}

std::string HotDessert::cookMeal(std::string prepMethod)
{
    return "Warm ";
}

#endif