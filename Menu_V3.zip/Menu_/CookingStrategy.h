#ifndef COOKINGSTRATEGY_H
#define COOKINGSTRATEGY_H

#include <iostream>

class CookingStrategy
{
    public:
        virtual std::string cookMeal(std::string prepMethod) = 0;
        virtual ~CookingStrategy() {};
};

class Fry : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Fry() {};
};

class Grill : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Grill() {};
};

class Bake : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Bake() {};
};

class Boil : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Boil() {};
};

class Sushi : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Sushi() {};
};

class Saute : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Saute() {};
};

class Simmer : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Simmer() {};
};

class NoCook : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~NoCook() {};
};

class Salad : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~Salad() {};
};

class ColdDessert : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~ColdDessert() {};
};

class HotDessert : public CookingStrategy
{
    virtual std::string cookMeal(std::string prepMethod);
    ~HotDessert() {};
};

#endif